# Metric Card For Japanese SQuAD
heavily refer to https://github.com/huggingface/datasets/tree/main/metrics/squad
